import React from 'react'
import Navbar from '../components/Navbar/NavBar'

const SubCategory = () => {
  return (
   
    <div>
         <Navbar />

         <div className="section">
            
         </div>

         <h1>Subcat</h1>
    </div>
  )
}

export default SubCategory